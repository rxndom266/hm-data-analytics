# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cleanse']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'cleanse',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
}


setup(**setup_kwargs)
