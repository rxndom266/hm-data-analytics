from pyspark.sql.functions import col, lit, trim, current_timestamp, months_between, date_format, coalesce, to_date, when, round
from delta.tables import *
import urllib

spark = SparkSession \
    .builder \
    .appName("Transform") \
    .config("spark.sql.legacy.timeParserPolicy", "CORRECTED") \
    .getOrCreate()

emptyRDD = spark.sparkContext.emptyRDD()

transconfig = {
    "activity":{
        "base_activity_types":[
            "email_sent",
            "email_open",
            "email_clickthrough",
            "incoming_call",
            "webclick"
        ],
        "fields":{
            "email_event_id": "email_event_id",
            "mastered_person_id": "mastered_person_id",
            "source_person_id": "source_person_id",
            "source_activity_id":"source_activity_id",
            "subject_line": "subject_line",
            "asset_id": "asset_id",
            "asset_name": "asset_name",
            "email_sent_datetime": "email_sent_datetime",
            "email_opened_datetime": "email_opened_datetime",
            "email_clickthrough_datetime": "email_clickthrough_datetime",
            "email_web_url": "email_web_url",
            "email_clicked_through_url": "email_clicked_through_url",
            "campaign_id": "campaign_id",
            "phone_number_to":"phone_number_to",
            "phone_number_from":"phone_number_from",
            "call_tracking_number":"call_tracking_number",
            "direction":"direction",
            "call_status_code":"call_status_code",
            "call_start_datetime":"call_start_datetime",
            "call_end_datetime":"call_end_datetime",
            "call_duration":"call_duration",
            "activity_type":"activity_type",
            "activity_datetime":"activity_datetime",
            "referrer_url":"referrer_url",
            "landing_page_url":"landing_page_url",
            "page_visited":"page_visited",
            "number_of_pages":"number_of_pages",
            "start_datetime":"start_datetime",
            "end_datetime":"end_datetime",
            "first_name":"first_name",
            "last_name":"last_name",
            "street_address":"street_address_1",
            "city":"city",
            "state":"state_province",
            "postal_code":"postal_code",
            "gender_code":"gender_code",
            "birth_date":"birth_date",
            "home_phone":"home_phone",
            "primary_email":"primary_email",
            "base_activity_type":"base_activity_type",
            "base_activity_id":"base_activity_id",
            "base_activity_datetime":"base_activity_datetime"
        },
        "email_clickthrough": {
            "id":"email_event_id",
            "datetime":"email_clickthrough_datetime",
            "mandatory": [
                "email_event_id",
                "source_person_id",
                "data_source",
                "subject_line",
                "asset_id",
                "asset_name",
                "email_sent_datetime",
                "email_opened_datetime",
                "email_clickthrough_datetime",
                # "email_web_url",
                # "email_clicked_through_url",
                "campaign_id"
            ],
          "empty":[]
        },
        "email_open": {
            "id":"email_event_id",
            "datetime":"email_opened_datetime",
            "mandatory": [
                "email_event_id",
                "source_person_id",
                "data_source",
                # "subject_line",
                "asset_id",
                # "asset_name",
                "email_sent_datetime",
                "email_opened_datetime",
                # "email_web_url",
                "campaign_id"
            ],
          "empty":[
            "email_clickthrough_datetime"
          ]
        },
        "email_sent": {
            "id":"email_event_id",
            "datetime":"email_sent_datetime",
            "mandatory": [
                "email_event_id",
                "source_person_id",
                "data_source",
                # "subject_line",
                "asset_id",
                # "asset_name",
                "email_sent_datetime",
                # "email_web_url",
                "campaign_id"
            ],
          "empty":[
            "email_clickthrough_datetime",
            "email_opened_datetime"
          ]
        },
        "incoming_call":{
            "id":"source_activity_id",
            "datetime":"call_start_datetime",
            "mandatory":[
                "source_person_id",
                "source_activity_id",
                "data_source",
                "phone_number_to",
                "phone_number_from",
                "call_tracking_number",
                # "direction",
                "call_status_code",
                "call_start_datetime",
                "call_end_datetime",
                "campaign_id",
                # "first_name",
                # "last_name",
                # "street_address",
                # "city",
                # "state",
                # "postal_code",
                # "gender_code",
                # "birth_date",
                # "home_phone",
                # "primary_email"
            ],
          "empty":[]
        },
        "webclick":{
            "id":"source_activity_id",
            "datetime":"activity_datetime",
            "mandatory":[
                "source_person_id",
                "source_activity_id",
                "data_source",
                "activity_type",
                "activity_datetime",
                # "referrer_url",
                # "landing_page_url",
                "page_visited",
                "number_of_pages",
                "start_datetime",
                "end_datetime",
                # "first_name",
                # "last_name",
                # "street_address",
                # "city",
                # "state",
                # "postal_code",
                # "gender_code",
                # "birth_date",
                # "home_phone",
                # "primary_email"
            ],
          "empty":[]
        }
    },
    "ig_person": {
        "fields": {
            "source_person_id": "insta_id",
            "first_name": "first_name",
            "middle_name": "middle_name",
            "last_name": "last_name",
            "street_address": "street",
            "city": "city",
            "state": "state",
            "zipcode": "zipcode",
            "gender": "gender",
            "birth_date": "birthdate",
            "phone": "mobile",
            "home_phone": "home_phone",
            "primary_email": "email",
            "secondary_email": "secondary_email",
            "marital_status_code": "marital_status_code",
            "race_code": "race_code",
            "race_description": "race_description",
            "religion_code": "religion_code",
            "religion_description": "religion_description"
            
        },
        "date_formats":["yyyy-MM-dd", 'MM-dd-yyyy', "dd-MM-yyyy", 'yyyy/MM/dd', 'MM/dd/yyyy', 'dd/MM/yyyy'],
        "date_pattern":'yyyy-MM-dd'
    },
    "fb_person": {
        "fields": {
            "source_person_id": "FacebookId",
            "first_name": "FirstName",
            "last_name": "LastName",
            "middle_name":"MiddleName",
            "street_address": "MailingStreet",
            "city": "MailingCity",
            "state": "MailingState",
            "zipcode": "MailingZipCode",
            "gender": "Gender",
            "birth_date": "Birthdate",
            "phone": "Mobile",
            "primary_email": "PrimaryEmail",
            "home_phone": "home_phone",
            "secondary_email": "secondary_email",
            "marital_status_code": "marital_status_code",
            "race_code": "race_code",
            "race_description": "race_description",
            "religion_code": "religion_code",
            "religion_description": "religion_description"
        },
        "date_formats":["yyyy-MM-dd", 'MM-dd-yyyy', "dd-MM-yyyy", 'yyyy/MM/dd', 'MM/dd/yyyy', 'dd/MM/yyyy'],
        "date_pattern":'yyyy-MM-dd'
    },
    "crm_person": {
        "fields": {
            "source_person_id": "crm_id",
            "first_name": "first_name",
            "middle_name": "middle_name",
            "last_name": "last_name",
            "street_address": "street",
            "city": "city",
            "state": "state",
            "zipcode": "zipcode",
            "gender": "gender",
            "birth_date": "birthdate",
            "marital_status_code": "marital_status_code",
            "race_code": "race_code",
            "race_description": "race_description",
            "religion_code": "religion_code",
            "religion_description": "religion_description",
            "home_phone": "home_phone",
            "phone": "mobile_phone",
            "primary_email": "primary_email",
            "secondary_email": "secondary_email"
        },
        "date_formats":["yyyy-MM-dd", 'MM-dd-yyyy', "dd-MM-yyyy", 'yyyy/MM/dd', 'MM/dd/yyyy', 'dd/MM/yyyy'],
        "date_pattern":'yyyy-MM-dd'
    },    
}

def purge(path):
  dbutils.fs.rm(path, recurse=True)

def transform(load_id, load_type, data_source, srcpath, destpath):

    df = spark.read.csv(srcpath, header='true', inferSchema='false')
    config = transconfig[load_type]                    
    null = '--'

    # renaming columns
    for k, v in config['fields'].items():
        if v in df.columns:
            df = df.withColumnRenamed(v, k).withColumn(k, when(col(k).isNull() | (trim(k)=='') | (col(k)==null), lit(null)).otherwise(trim(k)))
        else:
            df = df.withColumn(k, lit(null))

    print("exiting with", len(df.columns), "columns")

    # adding metadata
    df = df.withColumn('data_source', lit(data_source))\
        .withColumn('create_datetime', date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss'))\
        .withColumn('update_datetime', date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss'))\
        .withColumn('delete_flag', lit(0))\
        .withColumn('load_id', lit(load_id))

    emptyCDM = spark.createDataFrame(emptyRDD, df.schema) # 47 columns
    
    if(load_type=='activity'):
        # classifying activities
        res = emptyCDM
        for typ in config['base_activity_types']:
            temp = df
            for k in config[typ]['mandatory']:
                temp = temp.where((col(k)!=null) & (col(k).isNotNull()) & (col(k)!=''))
            for k in config[typ]['empty']:
                temp = temp.where((col(k)==null) | (col(k).isNull()) | (col(k)==''))
            df = df.subtract(temp)
            temp = temp.withColumn('base_activity_type', lit(typ))\
                .withColumn('base_activity_id', col(config[typ]['id']))\
                .withColumn('base_activity_datetime', col(config[typ]['datetime']))
            print(temp.count(), typ)
            res = res.union(temp)
        res = res.union(df)
        # persist to Delta
        try:
            res.write.format('delta').save(destpath)
        except:
            res.write.format('delta').mode('append').save(destpath)

    else:
        formats = config['date_formats']
        pattern = config['date_pattern']
        # adding age and mastered_person_id
        df = df.withColumn("age", round(months_between(current_timestamp(),date_format(coalesce(*[to_date('birth_date', f) for f in formats]), pattern))/lit(12),0))\
            .withColumn("mastered_person_id", lit(null))

        #persist to Delta
        try:
            df.write.format('delta').save(destpath)
        except:
            df.write.format('delta').mode('append').save(destpath)
    

    print('transform done')
    return
