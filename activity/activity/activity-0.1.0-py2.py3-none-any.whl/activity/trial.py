def func():
    print('hello')